		
# python testing

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from random import randint
browser = webdriver.Firefox()

browser.set_page_load_timeout(30)
browser.get("https://jungle-socks.herokuapp.com/")
assert “JungleSocks” in browser.title # this will check whether the value is True or not

search = browser.find_element_by_id(“line_item_quantity_zebra”)
search.send_keys(“25”)

search = browser.find_element_by_id(“line_item_quantity_lion”)
search.send_keys(“15”)

search = browser.find_element_by_id(“line_item_quantity_elephant”)
search.send_keys(“10”)

search = browser.find_element_by_id(“line_item_quantity_giraffe”)
search.send_keys(“20”)


# have to select ship to state 
mySelect = Select(browser.find_element_by_name("state"))
mySelect.select_by_value("AZ")


submit_button = browser.find_element_by_name(“commit”)
submit_button.click()
delay = 10 # seconds max wait
browser.save_screenshot(“JungleSocks”.png”)
browser.close() # close browser
