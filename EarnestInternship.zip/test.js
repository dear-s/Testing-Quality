
require('chromedriver');
const assert = require('assert');
const {Builder, Key, By, until} = require('selenium-webdriver');
describe('Checkout Google.com', function () {
    let driver;
    before(async function() {
        driver = await new Builder().forBrowser('chrome').build();
    });
	
    it('Search on Google', async function() {
        // First Test Case - passed
        await driver.get('https://jungle-socks.herokuapp.com/');
        
		await driver.findElement(By.id('line_item_quantity_zebra')).sendKeys('1')
		await driver.findElement(By.id('line_item_quantity_lion')).sendKeys('1')
		await driver.findElement(By.id('line_item_quantity_elephant')).sendKeys('1')
		await driver.findElement(By.id('line_item_quantity_giraffe')).sendKeys('1')

		//selecting from dropdown
		await driver.findElement(By.name('state')).sendKeys('california', Key.RETURN)
		await driver.wait(until.elementLocated(By.name('commit')), 10000).click();
		
        let title = await driver.getTitle();
        // checking title after clicking on "checkout" button
		assert.equal(title, 'JungleSocks');
		
		
		
		
		// Second Test Case - FAILED
        await driver.get('https://jungle-socks.herokuapp.com/');
        
		await driver.findElement(By.id('line_item_quantity_zebra')).sendKeys('100')
		await driver.findElement(By.id('line_item_quantity_lion')).sendKeys('100')
		await driver.findElement(By.id('line_item_quantity_elephant')).sendKeys('100')
		await driver.findElement(By.id('line_item_quantity_giraffe')).sendKeys('100')

		//selecting from dropdown
		await driver.findElement(By.name('state')).sendKeys('california')
		
		// check for authenticity
		z_val = driver.findElement(By.id('line_item_quantity_zebra'));
		zebra_value_input = z_val.getText();
		try{
			assert(zebra_value_input <= 23);
		}
		catch(err){
			console.log("error in zebra quantity - it should be less than or equal to 23");
		}
		
		
		l_val = driver.findElement(By.id('line_item_quantity_lion'));
		lion_value_input = l_val.getText();
		try{
			assert(lion_value_input <= 12);
		}
		catch(err){
			console.log("error in lion quantity - it should be less than or equal to 12");
		}
		
		
		e_val = driver.findElement(By.id('line_item_quantity_elephant'));
		ele_value_input = e_val.getText
		try{
			assert(ele_value_input <= 3);
		}
		catch(err){
			console.log("error in elephant quantity - it should be less than or equal to 3");
		}
		
		
		g_val = driver.findElement(By.id('line_item_quantity_giraffe'));
		giraffe_value_input = g_val.getText();
		try{
			assert(giraffe_value_input <= 15);
		}
		catch(err){
			console.log("error in giraffe quantity - it should be less than or equal to 15");
		}
		
		
		await driver.wait(until.elementLocated(By.name('commit')), 10000).click();
		
        let title1 = await driver.getTitle();
        // checking title after clicking on "checkout" button
		assert.equal(title1, 'JungleSocks');
		assert.equal(title, 'JungleSocks');
		
		
		
		
    });
	
    // close
    after(() => driver && driver.quit());
})